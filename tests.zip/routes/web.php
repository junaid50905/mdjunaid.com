<?php

use App\Http\Controllers\FrontendController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/



Route::get('/', [FrontendController::class, 'welcome'])->name('welcome');
Route::get('/blog/{blogId}', [FrontendController::class, 'blog'])->name('blog');
Route::post('/contact-form', [FrontendController::class, 'submitContactForm'])->name('submit.contact.form');
