<!DOCTYPE html>
<html lang="ru">

<?php echo $__env->make('layouts.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <?php echo $__env->make('layouts.includes.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('main-panel'); ?>


    <script src="<?php echo e(asset('frontend')); ?>/js/main.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/js/fontawesome.all.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
        $(document).ready(function() {
            <?php if(Session::has('success')): ?>
                toastr.options = {
                    "progressBar": true,
                    "closeButton": true,
                }
                toastr.success("<?php echo e(Session::get('success')); ?>", 'Success!', {
                    timeOut: 12000
                })
            <?php endif; ?>

            <?php if(Session::has('error')): ?>
                toastr.options = {
                    "progressBar": true,
                    "closeButton": true,
                }
                toastr.error("<?php echo e(Session::get('error')); ?>", 'Error!', {
                    timeOut: 3000
                })
            <?php endif; ?>
        });
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\mdjunaid\resources\views/layouts/master.blade.php ENDPATH**/ ?>