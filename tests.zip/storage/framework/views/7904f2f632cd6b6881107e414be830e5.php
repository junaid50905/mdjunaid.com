<div id="preloader">
        <div class="loader">
            <div class="circle"></div>
            <div class="circle"></div>
            <div class="circle"></div>
        </div>
    </div>
<?php /**PATH C:\laragon\www\mdjunaid\resources\views/layouts/includes/preloader.blade.php ENDPATH**/ ?>