<div class="header">
            <div class="header__left">
                <div class="header__letter">J</div>
                <div class="header__socials">
                    <a href="https://www.facebook.com/junaid.hossain.arman" target="_blank">
                        <i class="fa-brands fa-facebook"></i>
                    </a>
                    <a href="https://www.linkedin.com/in/junaid-hossain-arman/" target="_blank">
                        <i class="fa-brands fa-linkedin"></i>
                    </a>
                    <a href="https://github.com/junaid50905" target="_blank">
                        <i class="fa-brands fa-github"></i>
                    </a>
                    <a href="javascript:;" onclick="window.open('mailto:junaidhossain0905@gmail.com')" target="_blank">
                        <i class="fa-solid fa-envelope"></i>
                    </a>
                </div>
            </div>
            <div class="header__right">
                <ul class="header__menu">
                    <li class="active"><a class="js-scroll-link" href="javascript:;" data-link="0">HOME</a></li>
                    <li><a class="js-scroll-link" href="javascript:;" data-link="1">Projects</a></li>
                    <li><a class="js-scroll-link" href="javascript:;" data-link="2">Education</a></li>
                    <li><a class="js-scroll-link" href="javascript:;" data-link="3">testimonials</a></li>
                    <li><a class="js-scroll-link" href="javascript:;" data-link="4">experience</a></li>
                    <li><a class="js-scroll-link" href="javascript:;" data-link="5">blog</a></li>
                    <li><a class="js-scroll-link" href="javascript:;" data-link="6">CONTACT</a></li>
                </ul>
                <div class="header__phone">
                    <a href="tel:+8801621059282">+8801621059282</a>
                </div>
            </div>
        </div>
<?php /**PATH C:\laragon\www\mdjunaid\resources\views/layouts/includes/header.blade.php ENDPATH**/ ?>