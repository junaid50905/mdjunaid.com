<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contact Form Submission</title>
</head>
<body>
    <p><strong>Name:</strong> <?php echo e($name); ?></p>
    <p><strong>Email:</strong> <?php echo e($email); ?></p>
    <p><strong>Message:</strong> <?php echo e($user_message); ?></p> <!-- Updated variable name -->
</body>
</html>
<?php /**PATH C:\laragon\www\mdjunaid\resources\views/email-template.blade.php ENDPATH**/ ?>